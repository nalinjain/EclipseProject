package stepDefinations;


import io.cucumber.java.After;
import io.cucumber.java.Before;
//import io.cucumber.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.junit.Cucumber;


import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumberHooks.Hooks;

@RunWith(Cucumber.class)
public class stepDefination {

	protected WebDriver driver;
	@Before
	public void setUp() {
		String exePath = "driver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		driver = new ChromeDriver();
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
    @Given("^User is on Google Home Page$")
    public void user_is_on_google_home_page() throws Throwable {
    	driver.get("https://google.com");
    	//driver.wait(3000);
    	System.out.println("Home Page");
    	
    	
   // 	 throw new PendingException();
    }

    @When("^User search keyword$")
    public void user_search_keyword() throws Throwable {
    	WebElement search=driver.findElement(By.xpath("//input[@name='q']"));
    	search.sendKeys("Hello");
    	search.submit();
    	System.out.println("search");
    	//driver.wait(2000);
    	 //  throw new PendingException();
    }

    @Then("^Result shows$")
    public void result_shows() throws Throwable {
     
    	System.out.println("result");
    	
    	//  throw new PendingException();
    }

}